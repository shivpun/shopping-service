package com.weboxapps.mail.controller;

import org.springframework.web.bind.annotation.RestController;

import com.weboxapps.mail.properties.WeboxAppsMailProperties;

@RestController
public class SimpleMailController {
	
	private WeboxAppsMailProperties WeboxAppsMailProperties;
	
	public SimpleMailController(WeboxAppsMailProperties WeboxAppsMailProperties) {
		this.WeboxAppsMailProperties = WeboxAppsMailProperties;
		System.out.println(this.WeboxAppsMailProperties);
	}
}
