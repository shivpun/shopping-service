package com.weboxapps.mail.configuration;

public class SampleA {
	
	private String name;
	
	public SampleA(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "SampleA [name=" + name + "]";
	}
}
