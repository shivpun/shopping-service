package com.weboxapps.mail.controller;

import static java.util.Optional.ofNullable;

import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.weboxapps.mail.domain.MailInfo;
import com.weboxapps.mail.properties.WeboxAppsMailProperties;

public interface EmailService {
	
	public String processTemplate(MailInfo mailInfo);
	
	default MimeMessageHelper createMimeMessage(MimeMessage message, MailInfo mailInfo) throws MessagingException {
		MimeMessageHelper helper = new MimeMessageHelper(message, true, fetchObhProperties().getCharsetName());
		helper.setSentDate(new Date());
		if (!CollectionUtils.isEmpty(mailInfo.getMailTo())) {
			helper.setTo(mailInfo.getMailTo().stream().toArray(String[]::new));
		}
		if (!CollectionUtils.isEmpty(mailInfo.getMailCC())) {
			helper.setCc(mailInfo.getMailCC().stream().toArray(String[]::new));
		}
		if (!CollectionUtils.isEmpty(mailInfo.getMailBCC())) {
			helper.setBcc(mailInfo.getMailBCC().stream().toArray(String[]::new));
		}
		if (StringUtils.hasText(mailInfo.getSubject())) {
			helper.setSubject(mailInfo.getSubject());
		}
		if (StringUtils.hasText(mailInfo.getContent())) {
			helper.setText(mailInfo.getContent(), true);
		}
		if (StringUtils.hasText(mailInfo.getMailFrom())) {
			helper.setFrom(mailInfo.getMailFrom());
		}
		return helper;
	}
	
	default boolean allowIncludedPattern(List<String> mailId) {
		boolean allowIncludedPattern = true;
		if (CollectionUtils.isEmpty(fetchObhProperties().getIncludePatterns())) {
			return allowIncludedPattern;
		}
		return allowIncludedPattern;
	}
	
	default boolean blockExcludedPattern(List<String> mailId) {
		boolean blockPattern = true;
		if (CollectionUtils.isEmpty(fetchObhProperties().getExcludePatterns())) {
			return blockPattern;
		}
		return blockPattern;
	}
	
	default String mailFrom(MailInfo mailInfo) {
		return ofNullable(mailInfo.getMailFrom()).orElse(fetchObhProperties().getFrom());
	}
	
	default void sendMail(MimeMessage message) {
		getEmailSender().send(message);
	}
	
	public JavaMailSender getEmailSender();
	
	public WeboxAppsMailProperties fetchObhProperties();
}
