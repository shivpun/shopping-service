package com.weboxapps.mail.configuration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;

import com.weboxapps.mail.controller.EmailService;
import com.weboxapps.mail.controller.FreeMarkerEmailServiceImpl;
import com.weboxapps.mail.properties.WeboxAppsMailProperties;

@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(WeboxAppsMailProperties.class)
public class MailAutoConfiguration {
	
	private static final String FREEMARKER_TEMPLATE_PARSER = "freemarker"; 
	
	@ConditionalOnProperty(prefix = "obh.mail.template-parser", havingValue = FREEMARKER_TEMPLATE_PARSER)
	public EmailService freeMarkerEmailService(JavaMailSender javaMailSender, WeboxAppsMailProperties WeboxAppsMailProperties, freemarker.template.Configuration configurer) {
		return new FreeMarkerEmailServiceImpl(javaMailSender, WeboxAppsMailProperties, configurer);
	}
}
