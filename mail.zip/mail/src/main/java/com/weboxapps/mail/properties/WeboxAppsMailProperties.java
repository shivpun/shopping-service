package com.weboxapps.mail.properties;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "weboxapps.mail")
public class WeboxAppsMailProperties {
	
	private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
	
	private Charset charset = DEFAULT_CHARSET;

	private String from;
	
	private String templateParser;
	
	private List<String> includePatterns;

	private List<String> excludePatterns;
	
	public Charset getCharset() {
		return charset;
	}
	
	public String getCharsetName() {
		return charset.displayName();
	}

	public void setCharset(Charset charset) {
		this.charset = charset;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}
	
	public String getTemplateParser() {
		return templateParser;
	}

	public void setTemplateParser(String templateParser) {
		this.templateParser = templateParser;
	}

	public List<String> getIncludePatterns() {
		return includePatterns;
	}

	public void setIncludePatterns(List<String> includePatterns) {
		this.includePatterns = includePatterns;
	}

	public List<String> getExcludePatterns() {
		return excludePatterns;
	}

	public void setExcludePatterns(List<String> excludePatterns) {
		this.excludePatterns = excludePatterns;
	}
}
