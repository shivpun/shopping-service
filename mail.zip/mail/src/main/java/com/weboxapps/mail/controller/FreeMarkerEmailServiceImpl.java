package com.weboxapps.mail.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.weboxapps.mail.domain.MailInfo;
import com.weboxapps.mail.properties.WeboxAppsMailProperties;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

public class FreeMarkerEmailServiceImpl implements EmailService {
	
	private JavaMailSender emailSender;

	private WeboxAppsMailProperties WeboxAppsMailProperties;
	
	private Configuration configurer;

	public FreeMarkerEmailServiceImpl(JavaMailSender emailSender, WeboxAppsMailProperties WeboxAppsMailProperties, Configuration configurer) {
		this.emailSender = emailSender;
		this.WeboxAppsMailProperties = WeboxAppsMailProperties;
		this.configurer = configurer;
	}

	@Override
	public String processTemplate(MailInfo mailInfo) {
		Map<String, Object> dataModel = new HashMap<String, Object>();
		try {
			dataModel.put("mailInfo", mailInfo);
			Template template = configurer.getTemplate(mailInfo.getTemplate());
			return FreeMarkerTemplateUtils.processTemplateIntoString(template, dataModel);
		} catch (IOException | TemplateException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public JavaMailSender getEmailSender() {
		return this.emailSender;
	}

	@Override
	public WeboxAppsMailProperties fetchObhProperties() {
		return this.WeboxAppsMailProperties;
	}
}
