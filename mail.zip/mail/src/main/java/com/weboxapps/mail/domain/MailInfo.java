package com.weboxapps.mail.domain;

import java.io.Serializable;
import java.util.List;

public class MailInfo implements Serializable {

	private static final long serialVersionUID = 1239411316764052153L;

	private String content;

	private List<String> mailTo;

	private String mailFrom;

	private List<String> mailCC;

	private List<String> mailBCC;

	private String subject;

	private String template;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<String> getMailTo() {
		return mailTo;
	}

	public void setMailTo(List<String> mailTo) {
		this.mailTo = mailTo;
	}

	public String getMailFrom() {
		return mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public List<String> getMailCC() {
		return mailCC;
	}

	public void setMailCC(List<String> mailCC) {
		this.mailCC = mailCC;
	}

	public List<String> getMailBCC() {
		return mailBCC;
	}

	public void setMailBCC(List<String> mailBCC) {
		this.mailBCC = mailBCC;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	@Override
	public String toString() {
		return "MailInfo [content=" + content + ", mailTo=" + mailTo + ", mailFrom=" + mailFrom + ", mailCC=" + mailCC
				+ ", mailBCC=" + mailBCC + ", subject=" + subject + ", template=" + template + "]";
	}
}
